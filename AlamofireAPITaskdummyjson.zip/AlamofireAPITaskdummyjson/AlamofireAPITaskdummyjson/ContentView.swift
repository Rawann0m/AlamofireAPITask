//
//  ContentView.swift
//  AlamofireAPITaskdummyjson
//
//  Created by Rawan on 19/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationStack {
            ZStack{
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack {
                    // navigation
                    NavigationLink(destination: GetView()) {
                        Text("Fetch Data")
                            .padding()
                            .background(Color.black.opacity(0.7))
                            .foregroundColor(.gray)
                            .cornerRadius(10)
                            .font(.title)
                    }
                    .padding()
                    NavigationLink(destination: PostView()) {
                        Text("Post Data")
                            .padding()
                            .background(Color.black.opacity(0.7))
                            .foregroundColor(.gray)
                            .cornerRadius(10)
                            .font(.title)
                    }
                }
                .navigationTitle("")
                
                
            }
        }
    }
}

#Preview {
    ContentView()
}

