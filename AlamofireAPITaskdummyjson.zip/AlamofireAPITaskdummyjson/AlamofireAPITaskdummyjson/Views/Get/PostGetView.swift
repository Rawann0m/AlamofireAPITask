//
//  PostGetView.swift
//  AlamofireAPITaskdummyjson
//
//  Created by Rawan on 19/09/1446 AH.
//
import SwiftUI

struct GetView: View {
    @StateObject private var viewModel = ViewModel()
    @State private var isDataFetched = false
    @State private var hasLoaded = false //  Prevent Recursive Calls
    var body: some View {
        NavigationStack {
            ZStack {
                // Gray background
                Color.gray.opacity(0.2)
                    .edgesIgnoringSafeArea(.all)
                VStack{
                    //if the data isnt fetched then call the method fetch and remove the burron after
                    if !isDataFetched {
                        //button to fetch the data
                        Button("Fetch Data") {
                            viewModel.fetchData()
                            isDataFetched = true
                        }
                        .padding()
                        .background(Color.black.opacity(0.7))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    if viewModel.isLoading {
                        ProgressView("Loading...") // Show Loader
                            .progressViewStyle(CircularProgressViewStyle())
                            .scaleEffect(1.5)
                    } else {
                        List(viewModel.posts) { post in
                            Section(header: Text(post.title)
                                .font(.headline)
                                .bold()
                                .foregroundColor(.black)
                            ) {
                                VStack(alignment: .leading, spacing: 8) {
                                    // Post body
                                    Text(post.body)
                                        .font(.body)
                                        .foregroundColor(.gray)
                                    
                                    // Tags
                                    if !post.tags.isEmpty {
                                        HStack {
                                            Text("Tags:")
                                                .font(.subheadline)
                                                .bold()
                                                .foregroundColor(.blue)
                                            ForEach(post.tags, id: \.self) { tag in
                                                Text("#\(tag)")
                                                    .font(.caption)
                                                    .padding(.horizontal, 6)
                                                    .padding(.vertical, 4)
                                                    .background(Color.blue.opacity(0.1))
                                                    .cornerRadius(8)
                                            }
                                        }
                                    }
                                    
                                    // likes and dislikes
                                    HStack {
                                        HStack {
                                            Image(systemName: "hand.thumbsup.fill")
                                                .foregroundColor(.green)
                                            Text("\(post.reactions.likes)")
                                                .font(.subheadline)
                                        }
                                        
                                        HStack {
                                            Image(systemName: "hand.thumbsdown.fill")
                                                .foregroundColor(.red)
                                            Text("\(post.reactions.dislikes)")
                                                .font(.subheadline)
                                        }
                                    }
                                    .padding(.top, 5)
                                }
                                .padding(.vertical, 5)
                            }
                        }
                        
                        
                    }
                    
                    
                }//error handling
                .alert(isPresented: $viewModel.showErrorAlert) {
                    Alert(title: Text("Error"), message: Text(viewModel.errorMessage), dismissButton: .default(Text("OK")))
                }
                
            }
        }
    }
}

#Preview {
    GetView()
}
