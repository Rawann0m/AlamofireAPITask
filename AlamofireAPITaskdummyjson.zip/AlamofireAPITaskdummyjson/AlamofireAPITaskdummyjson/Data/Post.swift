//
//  Post.swift
//  AlamofireAPITaskdummyjson
//
//  Created by Rawan on 19/09/1446 AH.
//
import Foundation

// post structure
struct APIResponse: Codable {
    let posts: [Post]
}

struct Post: Codable, Identifiable {
    let id: Int
    let title: String
    let body: String
    let tags: [String]
    let reactions: Reactions  // ✅ This is an object, not a number
    let views: Int
    let userId: Int
}

struct Reactions: Codable {
    let likes: Int
    let dislikes: Int
}

