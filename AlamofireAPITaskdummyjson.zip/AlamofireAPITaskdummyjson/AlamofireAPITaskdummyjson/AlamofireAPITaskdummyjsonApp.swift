//
//  AlamofireAPITaskdummyjsonApp.swift
//  AlamofireAPITaskdummyjson
//
//  Created by Rawan on 19/09/1446 AH.
//

import SwiftUI

@main
struct AlamofireAPITaskdummyjsonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
